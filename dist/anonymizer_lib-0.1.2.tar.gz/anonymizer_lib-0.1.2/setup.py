import os
from setuptools import setup
from setuptools.command.install import install
from anonymizer_lib.config_generator import create_skeleton_config

# Base directory
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Read README from inside the package
with open(os.path.join(BASE_DIR, "anonymizer_lib", "ANONYMYZER_README.md"), encoding="utf-8") as f:
    long_description = f.read()

class CustomInstall(install):
    def run(self):
        super().run()
        config_path = os.path.join(os.getcwd(), "critical_words.json")
        if not os.path.exists(config_path):
            print(f"[anonymizer_lib] Creating skeleton config at {config_path}")
            create_skeleton_config(config_path)

setup(
    name="anonymizer_lib",
    version="0.1.2",
    packages=["anonymizer_lib"],
    include_package_data=True,   # 👈 ensures MANIFEST.in files are included
    cmdclass={"install": CustomInstall},
    long_description=long_description,
    long_description_content_type="text/markdown",
)
